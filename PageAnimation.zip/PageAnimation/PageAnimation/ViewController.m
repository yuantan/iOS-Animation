//
//  ViewController.m
//  PageAnimation
//
//  Created by xxg415 on 17/2/27.
//  Copyright © 2017年 xxg415. All rights reserved.
//

#import "ViewController.h"
#define SW [UIScreen mainScreen].bounds.size.width
#define SH [UIScreen mainScreen].bounds.size.height
@interface ViewController ()<UITableViewDelegate,UITableViewDataSource>
{
    UITableView * myTableView;
    UIImageView *myIView;
    UIView *myView;
    UIButton *myBtn;
    CGRect tableRect;
    CGRect screenRect;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //初始化table
    myTableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 20, SW, SH)];
    myTableView.delegate=self;
    myTableView.dataSource=self;
    [self.view addSubview:myTableView];
    
    //新页面
    myView=[[UIView alloc]init];
    myView.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"133.jpg"]];
    //新页面上的按钮
    myBtn=[[UIButton alloc]initWithFrame:CGRectMake(100, 100, 100, 100)];
    [myBtn setTitle:@"关闭" forState:UIControlStateNormal];
    [myBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [myBtn addTarget:self action:@selector(closePage) forControlEvents:UIControlEventTouchUpInside];
}


//关闭新页面
-(void)closePage
{
    //移除新页面上的按钮
    [myBtn removeFromSuperview];
    //收缩新页面
    [UIView animateWithDuration:1 animations:^{
        // 设置按钮透明度
        myView.alpha = 1;
        // 设置图片的新的frame
        myView.frame =screenRect;
    }completion:^(BOOL finished){
        if(finished)
        {
          //移除新页面
          [myView removeFromSuperview];
        }
    }];
}

//设置表的单元个数
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

//设置每个单元的行数
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 6;
}

//设置每个行的内容
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"reuse"];
      if(indexPath.row==2)
      {
          myIView=[[UIImageView alloc]initWithFrame:CGRectMake(0, 0, SW, (SH-20)/6)];
          myIView.image=[UIImage imageNamed:@"133.jpg"];
          [cell.contentView addSubview:myIView];
      }
      return cell;
}

//设置行高
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
      return (SH-20)/6;
}

//行选中操作
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.row==2)
    {
        //获取指定行在表中的位置大小
        tableRect = [tableView rectForRowAtIndexPath:indexPath];
        //行在表中位置转化为在屏幕中位置大小
        screenRect = [tableView convertRect:tableRect toView:[tableView superview]];
        //设置新页面位置大小同选中行一样
        myView.frame=screenRect;
        //添加新页面
        [self.view addSubview:myView];
        //动画放大新页面
        [UIView animateWithDuration:1 animations:^{
            // 设置按钮透明度
            myView.alpha = 1;
            // 设置图片的新的frame
            myView.frame =[UIScreen mainScreen].bounds;
        } completion:^(BOOL finished){
            //放大完毕后，添加新页面上的按钮
            [myView addSubview:myBtn];
        }];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end

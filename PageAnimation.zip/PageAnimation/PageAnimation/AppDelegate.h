//
//  AppDelegate.h
//  PageAnimation
//
//  Created by xxg415 on 17/2/27.
//  Copyright © 2017年 xxg415. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

